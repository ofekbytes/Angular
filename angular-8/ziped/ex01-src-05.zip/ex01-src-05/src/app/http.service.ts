import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; // Http API Import //

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private http: HttpClient) { } //add http variable

// communicating with api to get data (for the 'list' page)
  myMethod() {
    return console.log('I am a Service named myMethod()' );
  }

//get api
  getBeer() {
    // return this.http.get('../data/breweries.json')
    // return this.http.get('https://api.openbrewerydb.org/breweries')
    return this.http.get('https://ofekbytes.github.io/assets/json/temp/breweries.json')
    

  }

}


