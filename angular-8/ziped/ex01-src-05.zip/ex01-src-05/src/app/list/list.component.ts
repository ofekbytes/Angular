import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service'; //import service{ HttpService }

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  brews: object;

  //add service to "list" component (dependcy injection) //
  constructor(private _http: HttpService) { }


  //onload - run when the component is loaded //
  ngOnInit() {
  //  this._http.myMethod();

    ///!!//learn more about 'observables' and 'subscribe' property
    ///call service 'getBeer()'///
    this._http.getBeer().subscribe(data => {
      this.brews = data;
      console.log(this.brews);
    }); 
  }


}
